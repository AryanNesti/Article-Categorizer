The main files are the the tree_code.ipynb and solution.py

The solution.py holds the answer to section 5

tree_code.ipynb has the code for 1-4 parts

labels.csv is the answer to the test at the end of part 5

all the business.txt and not_business.txt .. etc are not needed they were for testing purposes at the time

samplecode.py is a file that has the same code as tree_code.ipynb but has some altered parts and errors